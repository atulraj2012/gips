// alert("welcome to Gurudev International Public School" )

 document.onreadystatechange = function () {
     if (document.readyState !== "complete") {
         document.querySelector("body").style.visibility = "hidden";
         document.querySelector("#loader").style.visibility = "visible";
     } else {
        document.querySelector("#loader").style.display = "none";
         document.querySelector("body").style.visibility = "visible";
     }
 };

var navLinks = document.getElementById("navLinks")

function showMenu() {
    navLinks.style.right = "0";
}

function hideMenu() {
    navLinks.style.right = "-200px";
}